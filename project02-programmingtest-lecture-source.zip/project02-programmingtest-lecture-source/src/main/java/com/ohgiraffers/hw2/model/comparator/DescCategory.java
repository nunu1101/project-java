package com.ohgiraffers.hw2.model.comparator;

public class DescCategory {
}
