package com.ohgiraffers.test.controller;

import com.ohgiraffers.test.model.dto.BookDTO;

import java.beans.IntrospectionException;
import java.util.ArrayList;
import java.util.Scanner;

public class BookManager{

    ArrayList<BookDTO> arrayList = new ArrayList<>();
    public BookManager(){}

    BookDTO bookDTO = new BookDTO();

    Scanner sc = new Scanner(System.in);

    // 도서 추가 메소드
    public void addBook(BookDTO book){
        System.out.println("도서 번호 : ");
        int bNo = sc.nextInt();
        System.out.println("도서 제목 : ");
        String title = sc.nextLine();
        System.out.println("저자 : ");
        String author = sc.nextLine();
        sc.nextLine(); // 버퍼 초기화
        System.out.println("카테고리(1.인문, 2.자연과학, 3.의료, 4.기타) : ");
        int category = sc.nextInt();
        arrayList.add(new BookDTO());
    }

    // 도서 삭제 메소드
    public void deleteBook(int index){
        if(index > 0 && index < arrayList.size()) {
            arrayList.remove(index);
            System.out.println("도서 삭제 완료");
        } else {
            System.out.println("유효하지 않은 도서 번호 입니다.");
        }
    }

    // 도서 검색 메소드
    public int searchBook(String title){
        for(int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i).getTitle().equals(title)){
                return i;
            }
        }
        System.out.println("도서를 찾을 수 없습니다.");
        return -1; // 도서가 발견되지 않으면 -1 반환
    }

    // 도서 정보 출력 메소드
    public void printBook(int index){
        if(index >= 0 && index < arrayList.size()) {

        }
    }

    public void displayAll() throws IntrospectionException {
        System.out.println();
    }

    public void sortedBookList(BookDTO bookDTO){
    }

    public void printBookList(ArrayList<BookDTO> br) {

    }

}
