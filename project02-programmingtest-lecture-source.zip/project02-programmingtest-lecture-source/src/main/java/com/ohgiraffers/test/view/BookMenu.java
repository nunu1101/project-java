package com.ohgiraffers.test.view;

import com.ohgiraffers.test.controller.BookManager;
import com.ohgiraffers.test.model.dto.BookDTO;

import java.util.Scanner;

public class BookMenu {

    private  BookManager bm;
    private Scanner sc;
    public BookMenu() {
        this.bm = new BookManager();
        this.sc = new Scanner(System.in);
    }

    public void menu() {
        while (true) {
            System.out.println("========== 도서 관리 프로그램입니다. ==========");
            System.out.println("========== 프로그램을 선택해주세요. ===========");
            System.out.println("1. 도서 추가\n2. 도서 삭제\n3. 도서 검색\n4. 도서 정보 출력\n5. 도서 목록 전체 출력(오름차순)\n6. 도서 목록 전체 출력(내림차순)\n 7.종료 :");
            int choice = sc.nextInt();
            sc.nextLine();  // 버퍼 초기화
            switch (choice) {
                case 1:
                    bm.addBook(new BookDTO());
                    System.out.println(" 도서 추가 완료하였습니다. ");
                    break;
                case 2:

                    break;

            }

        }
    }


    BookDTO inputBook = new BookDTO(1, "", "");

    public String inputBookTitle() {
        return null;
    }

}






