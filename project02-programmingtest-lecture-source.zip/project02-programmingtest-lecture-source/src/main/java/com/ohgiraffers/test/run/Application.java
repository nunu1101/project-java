package com.ohgiraffers.test.run;

import com.ohgiraffers.test.controller.BookManager;
import com.ohgiraffers.test.view.BookMenu;

public class Application {
    public static void main(String[] args) {
        BookManager bookManager = new BookManager();
        BookMenu bookMenu = new BookMenu();
        bookMenu.menu();
    }
}
